This is a test directory for test_manifest.
