#!python
import sys
print(sys.executable)
